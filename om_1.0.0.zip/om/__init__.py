# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Om",
    "author" : "Matteo Fontana", 
    "description" : "Root Folder Generation for Project Jump Start",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "Italy",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Development" 
}


import bpy
import bpy.utils.previews
import platform
import os


addon_keymaps = {}
_icons = None


def sna_update_sna_setting_url_folder_2C1AE(self, context):
    sna_updated_prop = self.sna_setting_url_folder
    bpy.context.scene.sna_setting_url_folder = bpy.path.abspath(sna_updated_prop)


class SNA_OT_Open_64Efc(bpy.types.Operator):
    bl_idname = "sna.open_64efc"
    bl_label = "Open"
    bl_description = "Opens the selected URL Folder"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        openURLVar = bpy.context.scene.sna_setting_url_folder
        import os
        import subprocess

        def open_folder(path):
            # Check if the path exists
            if not os.path.exists(path):
                print(f"Path does not exist: {path}")
                return
            # Get the operating system
            system = platform.system()
            # Open folder in Finder (macOS)
            if system == "Darwin":
                subprocess.run(["open", path])
            # Open folder in File Explorer (Windows)
            elif system == "Windows":
                subprocess.run(["explorer", path.replace("/", "\\")])
            else:
                print(f"Unsupported operating system: {system}")
        # Example usage:
        # Set your path here
        folder_path = openURLVar
        # Call the function to open the folder
        open_folder(folder_path)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Switch_0C17A(bpy.types.Operator):
    bl_idname = "sna.switch_0c17a"
    bl_label = "Switch"
    bl_description = "Switches the Preset URL in the Add-On Preferences with this one"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.preferences.addons['om'].preferences.sna_preferences_url_folder = bpy.context.scene.sna_setting_url_folder
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_A2106(bpy.types.Operator):
    bl_idname = "sna.reset_a2106"
    bl_label = "Reset"
    bl_description = "Switches back to the preferences URL the directory path selected"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_setting_url_folder = bpy.context.preferences.addons['om'].preferences.sna_preferences_url_folder
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_OM_100_72B16(bpy.types.Panel):
    bl_label = 'Om 1.0.0'
    bl_idname = 'SNA_PT_OM_100_72B16'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Om'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Kind of Project', icon_value=0)
        layout.prop(bpy.context.scene, 'sna_kind_of_project', text=bpy.context.scene.sna_kind_of_project, icon_value=0, emboss=True, expand=True)
        layout.prop(bpy.context.scene, 'sna_name_of_the_project', text='Name of the project', icon_value=701, emboss=True)
        col_01F11 = layout.column(heading='', align=False)
        col_01F11.alert = False
        col_01F11.enabled = True
        col_01F11.active = True
        col_01F11.use_property_split = False
        col_01F11.use_property_decorate = False
        col_01F11.scale_x = 1.0
        col_01F11.scale_y = 1.0
        col_01F11.alignment = 'Expand'.upper()
        col_01F11.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_96490 = col_01F11.row(heading='', align=False)
        row_96490.alert = False
        row_96490.enabled = True
        row_96490.active = True
        row_96490.use_property_split = False
        row_96490.use_property_decorate = False
        row_96490.scale_x = 1.0
        row_96490.scale_y = 1.0
        row_96490.alignment = 'Expand'.upper()
        row_96490.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_96490.prop(bpy.context.scene, 'sna_setting_url_folder', text='Setting URL Folder', icon_value=26, emboss=True)
        row_96490.separator(factor=1.0)
        op = row_96490.operator('sna.reset_a2106', text='', icon_value=715, emboss=True, depress=False)
        col_4B8A7 = col_01F11.column(heading='', align=False)
        col_4B8A7.alert = False
        col_4B8A7.enabled = True
        col_4B8A7.active = True
        col_4B8A7.use_property_split = False
        col_4B8A7.use_property_decorate = False
        col_4B8A7.scale_x = 1.0
        col_4B8A7.scale_y = 1.0
        col_4B8A7.alignment = 'Expand'.upper()
        col_4B8A7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_C2A00 = col_4B8A7.row(heading='', align=False)
        row_C2A00.alert = False
        row_C2A00.enabled = True
        row_C2A00.active = True
        row_C2A00.use_property_split = False
        row_C2A00.use_property_decorate = False
        row_C2A00.scale_x = 1.0
        row_C2A00.scale_y = 1.0
        row_C2A00.alignment = 'Expand'.upper()
        row_C2A00.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_C2A00.operator('sna.open_64efc', text='Open Folder', icon_value=690, emboss=True, depress=False)
        op = row_C2A00.operator('sna.switch_0c17a', text='Save URL as Preset', icon_value=117, emboss=True, depress=False)
        col_4B8A7.label(text='Blend file options', icon_value=0)
        col_4B8A7.prop(bpy.context.preferences.addons['om'].preferences, 'sna_save_blender_file', text='Save also this .blend file', icon_value=0, emboss=True)
        col_4B8A7.prop(bpy.context.scene, 'sna_code_of_the_project', text='Code of the project', icon_value=0, emboss=True)
        col_4B8A7.prop(bpy.context.scene, 'sna_blend_file_subject_code', text='Blend file subject code', icon_value=0, emboss=True)
        col_4B8A7.prop(bpy.context.scene, 'sna_blend_file_name', text='Project File Name', icon_value=0, emboss=True)
        col_4B8A7.prop(bpy.context.scene, 'sna_version', text='Version', icon_value=0, emboss=True)
        col_4B8A7.separator(factor=1.0)
        col_91348 = col_4B8A7.column(heading='', align=False)
        col_91348.alert = False
        col_91348.enabled = True
        col_91348.active = True
        col_91348.use_property_split = False
        col_91348.use_property_decorate = False
        col_91348.scale_x = 1.0
        col_91348.scale_y = 2.0
        col_91348.alignment = 'Expand'.upper()
        col_91348.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_91348.operator('sna.run_698f2', text=('Create the folder and save this .blend file' if bpy.context.preferences.addons['om'].preferences.sna_save_blender_file else 'Create the folder'), icon_value=693, emboss=True, depress=False)
        col_91348.separator(factor=1.0)
        row_985DE = col_91348.row(heading='', align=False)
        row_985DE.alert = False
        row_985DE.enabled = True
        row_985DE.active = True
        row_985DE.use_property_split = False
        row_985DE.use_property_decorate = False
        row_985DE.scale_x = 1.0
        row_985DE.scale_y = 0.5709999799728394
        row_985DE.alignment = 'Expand'.upper()
        row_985DE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_985DE.template_icon(icon_value=_icons['OMAO_IMG_Logo_OmLogo_v01.jpg'].icon_id, scale=2.05400013923645)
        col_19C47 = row_985DE.column(heading='', align=False)
        col_19C47.alert = False
        col_19C47.enabled = True
        col_19C47.active = True
        col_19C47.use_property_split = False
        col_19C47.use_property_decorate = False
        col_19C47.scale_x = 1.5519999265670776
        col_19C47.scale_y = 1.0
        col_19C47.alignment = 'Expand'.upper()
        col_19C47.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_19C47.label(text='Created and Curated with Love by', icon_value=0)
        col_19C47.label(text='Matteo Fontana - 2024', icon_value=0)


class SNA_AddonPreferences_38A06(bpy.types.AddonPreferences):
    bl_idname = 'om'
    sna_save_blender_file: bpy.props.BoolProperty(name='Save blender file', description='Option to save or not the .blend file together with the generation', default=True)
    sna_preferences_url_folder: bpy.props.StringProperty(name='Preferences URL Folder', description='', default='', subtype='DIR_PATH', maxlen=0)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.prop(bpy.context.preferences.addons['om'].preferences, 'sna_preferences_url_folder', text='URL of Projects Folder', icon_value=0, emboss=True)
            layout.prop(bpy.context.preferences.addons['om'].preferences, 'sna_save_blender_file', text='Save also .blend file', icon_value=0, emboss=True)


class SNA_OT_Run_698F2(bpy.types.Operator):
    bl_idname = "sna.run_698f2"
    bl_label = "Run"
    bl_description = "Run the operation"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        kindOfProjectVar = bpy.context.scene.sna_kind_of_project
        nameOfProjectVar = bpy.context.scene.sna_name_of_the_project
        selectedURLVar = bpy.context.scene.sna_setting_url_folder
        saveBlendFileVar = bpy.context.preferences.addons['om'].preferences.sna_save_blender_file
        blendFileCodeVar = bpy.context.scene.sna_code_of_the_project
        blendFileSubjectCodeVar = bpy.context.scene.sna_blend_file_subject_code
        projectFileNameVar = bpy.context.scene.sna_blend_file_name
        verisonNumberVar = bpy.context.scene.sna_version

        def create_project_folder_structure(root_code, name, root_url, save_blend=False, blend_code=None, subject=None, project_file_name=None, version=None):
            # Construct the root folder name
            root_folder_name = f"{root_code}_{name}"
            root_folder_path = os.path.join(root_url, root_folder_name)
            # Check if the root folder already exists
            if os.path.exists(root_folder_path):
                print(f"Error: The root folder '{root_folder_name}' already exists at '{root_url}'. Operation aborted.")
                return
            # Define the folder structure
            folder_structure = {
                "_Master": ["00_Client", "10_Internal"],
                "00_Received": ["00_Client", "05_Internal"],
                "05_Production": {
                    "00_Render": ["00_Frames", "05_Video"],
                    "05_Editing": [],
                    "10_Cache": [],
                    "15_Data": [],
                    "20_Models": [],
                    "25_Textures": ["00_Graphics", "05_Materials", "10_SurfaceImperfections", "15_Bokehs"],
                    "30_Audio": ["00_SFX", "05_Tracks", "10_Edited"]
                },
                "10_SourceProjects": ["Blender", "Illustrator", "Photoshop"],
                "20_Temp": []
            }
            # Function to create folders recursively

            def create_folders(base_path, structure):
                for folder, subfolders in structure.items():
                    folder_path = os.path.join(base_path, folder)
                    os.makedirs(folder_path, exist_ok=True)
                    if isinstance(subfolders, dict):
                        create_folders(folder_path, subfolders)
                    elif isinstance(subfolders, list):
                        for subfolder in subfolders:
                            subfolder_path = os.path.join(folder_path, subfolder)
                            if not os.path.exists(subfolder_path):
                                os.makedirs(subfolder_path, exist_ok=True)
                            else:
                                print(f"Folder '{subfolder_path}' already exists, skipping creation.")
            # Create the root folder and the structure inside
            create_folders(root_folder_path, folder_structure)
            print(f"Project folder structure created at: {root_folder_path}")
            # Save the Blender file if save_blend is True
            if save_blend and blend_code and subject and project_file_name and version is not None:
                blender_folder_path = os.path.join(root_folder_path, "10_SourceProjects", "Blender")
                # Ensure the Blender folder exists
                if not os.path.exists(blender_folder_path):
                    try:
                        os.makedirs(blender_folder_path)
                        print(f"Directory created: {blender_folder_path}")
                    except Exception as e:
                        print(f"Error creating directory {blender_folder_path}: {e}")
                        return
                # Format the version to always have two digits
                version_str = f"{version:02}"
                # Construct the file name
                file_name = f"{blend_code}_BL_{subject}_{project_file_name}_v{version_str}.blend"
                # Construct the full path
                full_path = os.path.join(blender_folder_path, file_name)
                # Check if the file already exists
                if os.path.exists(full_path):
                    print(f"Error: The file '{file_name}' already exists at '{blender_folder_path}'. Operation aborted.")
                    return
                # Save the blender file
                try:
                    bpy.ops.wm.save_as_mainfile(filepath=full_path)
                    print(f"Blender file saved as: {full_path}")
                except Exception as e:
                    print(f"Error saving Blender file: {e}")
        # Example usage
        root_code = kindOfProjectVar  # This is the project code used for the root folder
        name = nameOfProjectVar
        root_url = selectedURLVar
        save_blend = saveBlendFileVar  # Boolean variable whether to save the blend file or not
        blend_code = blendFileCodeVar  # This is the code used for the Blender file
        subject = blendFileSubjectCodeVar
        project_file_name = projectFileNameVar
        version = verisonNumberVar
        create_project_folder_structure(root_code, name, root_url, save_blend, blend_code, subject, project_file_name, version)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_kind_of_project = bpy.props.EnumProperty(name='Kind of Project', description='The kind of project', items=[('P', 'P', 'Project', 0, 0), ('RnD', 'RnD', 'Research and Development', 0, 1), ('C', 'C', 'Client Project', 0, 2)])
    bpy.types.Scene.sna_name_of_the_project = bpy.props.StringProperty(name='Name of the Project', description='The name that identifies the project', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_setting_url_folder = bpy.props.StringProperty(name='Setting URL Folder', description='The directory where to create the root folder', default='', subtype='DIR_PATH', maxlen=0, update=sna_update_sna_setting_url_folder_2C1AE)
    bpy.types.Scene.sna_code_of_the_project = bpy.props.StringProperty(name='Code of the project', description='The code string which identifies the project used in all the files', default='', subtype='NONE', maxlen=4)
    bpy.types.Scene.sna_blend_file_subject_code = bpy.props.EnumProperty(name='Blend file subject code', description='The identifier string for the subject of this blend file.', items=[('Main', 'Main', 'Main file, containing all the content of the project', 0, 0), ('Prop', 'Prop', 'A prop file, containing a signle prop of the project', 0, 1), ('Env', 'Env', 'An environment file, containing environment data', 0, 2), ('Char', 'Char', 'A character file, containing a character for a project', 0, 3), ('Sim', 'Sim', 'A simulation file, containing simulation dat', 0, 4), ('Dress', 'Dress', 'A dress file, containing only tissue elements of the project', 0, 5), ('Animatic', 'Animatic', 'An animatic file, containing animation directions', 0, 6)])
    bpy.types.Scene.sna_blend_file_name = bpy.props.StringProperty(name='Blend file name', description='The name associated with this blend file', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_version = bpy.props.IntProperty(name='Version', description='The version of the Blender file you want to save', default=1, subtype='NONE', min=1)
    bpy.utils.register_class(SNA_OT_Open_64Efc)
    bpy.utils.register_class(SNA_OT_Switch_0C17A)
    bpy.utils.register_class(SNA_OT_Reset_A2106)
    bpy.utils.register_class(SNA_PT_OM_100_72B16)
    if not 'OMAO_IMG_Logo_OmLogo_v01.jpg' in _icons: _icons.load('OMAO_IMG_Logo_OmLogo_v01.jpg', os.path.join(os.path.dirname(__file__), 'icons', 'OMAO_IMG_Logo_OmLogo_v01.jpg'), "IMAGE")
    bpy.utils.register_class(SNA_AddonPreferences_38A06)
    bpy.utils.register_class(SNA_OT_Run_698F2)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_version
    del bpy.types.Scene.sna_blend_file_name
    del bpy.types.Scene.sna_blend_file_subject_code
    del bpy.types.Scene.sna_code_of_the_project
    del bpy.types.Scene.sna_setting_url_folder
    del bpy.types.Scene.sna_name_of_the_project
    del bpy.types.Scene.sna_kind_of_project
    bpy.utils.unregister_class(SNA_OT_Open_64Efc)
    bpy.utils.unregister_class(SNA_OT_Switch_0C17A)
    bpy.utils.unregister_class(SNA_OT_Reset_A2106)
    bpy.utils.unregister_class(SNA_PT_OM_100_72B16)
    bpy.utils.unregister_class(SNA_AddonPreferences_38A06)
    bpy.utils.unregister_class(SNA_OT_Run_698F2)
